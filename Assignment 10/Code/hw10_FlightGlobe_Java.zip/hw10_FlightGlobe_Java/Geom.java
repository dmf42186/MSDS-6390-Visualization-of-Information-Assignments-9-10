// Super Class

import processing.core.*;
import java.util.ArrayList;
public abstract class Geom {
  // Properties
  PApplet p;
  //int r = 300;
  float lat = 0; //Error saying cannot convert from double to float so changed 0.0 to 0.
  float lon = 0; //Error saying cannot convert from double to float so changed 0.0 to 0.
  
  // Default Constructors
  public Geom() {
  }
  
  // Parameterized Constructors
  public Geom(PApplet p, float lat, float lon) {
    this.p = p;
    this.lat = lat;
    this.lon = lon;
  }
  
  // Methods
  // This method describes the sperical coordinate system which converts latitude and longitude to a 3D coordinate system
  public void plot() {
    float theta = p.radians(lat);
    float phi = p.radians(lon) + p.PI;

    float x = r * p.cos(theta) * p.cos(phi);
    float y = - r * p.sin(theta);
    float z = - r * p.cos(theta) * p.sin(phi);

    p.pushMatrix();
    p.translate(x, y, z);
    p.popMatrix();
  }
}